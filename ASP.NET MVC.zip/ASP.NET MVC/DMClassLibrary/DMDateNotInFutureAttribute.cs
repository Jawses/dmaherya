﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using DMClassLibrary;


namespace DMClassLibrary
{
    public class DMDateNotInFutureAttribute : ValidationAttribute
    {

        public DMDateNotInFutureAttribute()
        {
            ErrorMessage = "{0} is greater then current date/time";
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {   
            if (value == null || value.ToString() == "" )
                return ValidationResult.Success;

            DateTime cDate = DateTime.Now;
            DateTime vDate = (DateTime)value;

            if (vDate > cDate)
            {
                return new ValidationResult(string.Format(ErrorMessage, validationContext.DisplayName));
            }
            else
            {
                return ValidationResult.Success;
            }
            
        }

    }
}
