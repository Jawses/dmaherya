﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Text.RegularExpressions;


namespace DMClassLibrary
{
    public class DMValidations
    {
        public string DMCApitalize(string s)
        {
            if(string.IsNullOrEmpty(s))
            {
               return s;
            }
            else
            {
                s = s.ToLower().Trim();
                s = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(s);
                return s;
            }
        }

        public bool DMPostalCodeValidation(ref string s)
        {
            bool passed = false;

            Regex pattern = new Regex(@"^[ABCEGHJKLMNPRSTVXY-abceghjklmnprstvxy]\d[ABCEGHJKLMNPRSTVWXYZ-abceghjklmnprstvwxyz]\s?\d[ABCEGHJKLMNPRSTVWXYZ-abceghjklmnprstvwxyz] ?\d$", RegexOptions.IgnoreCase);

            if (string.IsNullOrEmpty(s))
                return true;

            if(!pattern.IsMatch(s))
            {
                passed = false;
            }
            else
            {
                s = s.ToUpper();

                if (!s.Contains(" "))
                    s.Insert(3, " ");

                passed = true;
            }
            return passed;
        }

        public bool DMZipCodeValidation(ref string s)
        {
            bool passed = false;

            s = s.Trim();
            s = Regex.Replace(s, "[^.0-9]", "");


            Regex pattern = new Regex(@"^\d{5}$|^\d{5}-\d{4}$|^\d{5}\d{4}$", RegexOptions.IgnoreCase);

            if (!pattern.IsMatch(s))
            {
                if (!Regex.IsMatch(s, @"^\d+$"))
                    return false;
            }

            if (s.Length == 5)
            {
                passed = true;
            }
            else if (s.Length == 9 )
            {
                s = s.Insert(5, "-");
                passed = true;
            }
            return passed;
        }

        public string DMCheckPhoneNumber(string s)
        {
            s = Regex.Replace(s, "[^.0-9]", "");

            if (s.Length == 10)
            {
                s = s.Insert(3, "-");
                s = s.Insert(7, "-");
            }
            return s;
        }
    }
}
