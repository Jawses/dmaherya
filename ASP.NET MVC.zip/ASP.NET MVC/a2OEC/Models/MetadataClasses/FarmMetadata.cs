﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using DMClassLibrary;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace a2OEC.Models
{
    
    [ModelMetadataTypeAttribute(typeof(FarmMetadata))]

    public partial class Farm : IValidatableObject
    {
        OECContext context = OECContext_Singleton.Context();
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            DMValidations validate = new DMValidations();
            Regex patternEmail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", RegexOptions.IgnoreCase);

            Name = TrimFunction(Name);
            Address = TrimFunction(Address);
            Town = TrimFunction(Town);
            County = TrimFunction(County);
            ProvinceCode = TrimFunction(ProvinceCode);
            PostalCode = TrimFunction(PostalCode);
            HomePhone = TrimFunction(HomePhone);
            CellPhone = TrimFunction(CellPhone);
            Email = TrimFunction(Email);
            Directions = TrimFunction(Directions);


            if (string.IsNullOrEmpty(Name))
                yield return new ValidationResult("Name is reqiered", new[] { "Name" });

            if (string.IsNullOrEmpty(ProvinceCode))
            {
                yield return new ValidationResult("Province code is reqiered", new[] { "ProvinceCode" });
            }
            else
            {
               ProvinceCode = ProvinceCode.ToUpper();
            }

            if(string.IsNullOrEmpty(Town) && string.IsNullOrEmpty(County))
                yield return new ValidationResult("At least one of Town or Country must be provided", new[] { "Town", "County" });

            if(string.IsNullOrEmpty(Email) && (string.IsNullOrEmpty(Address) || string.IsNullOrEmpty(PostalCode)))
                yield return new ValidationResult("Either Email or both address and postal must be provided", new[] { "Email", "Address", "PostalCode" });

            if(!string.IsNullOrEmpty(Email) && !patternEmail.IsMatch(Email))
                yield return new ValidationResult("Please, provide a valid email", new[] { "Email" });

            if (string.IsNullOrEmpty(HomePhone) && string.IsNullOrEmpty(CellPhone))
            {
                yield return new ValidationResult("Either Home phone or Cell phone must be provided", new[] { "HomePhone", "CellPhone" });
            }

            if(LastContactDate.HasValue && !DateJoined.HasValue)
                yield return new ValidationResult("Last contact date can't be provided unless date joined is also provided!", new[] { "LastContactDate"});

            if (LastContactDate < DateJoined)
                yield return new ValidationResult("Farmer cannot be contacted before he have joined the program", new[] { "LastContactDate" });

            if (!string.IsNullOrEmpty(PostalCode))
            {
                var country = context.Province.SingleOrDefault(a => a.ProvinceCode == ProvinceCode);

                if (country.CountryCode == "CA")
                {
                    string postalCode = PostalCode; //12345-6789

                    if (!validate.DMPostalCodeValidation(ref postalCode))
                    {
                        yield return new ValidationResult("Correcr Postal code is reqiered", new[] { "PostalCode" });
                    }
                }
                else if (country.CountryCode == "US")
                {
                    string zipCode = PostalCode;

                    if (!validate.DMZipCodeValidation(ref zipCode))
                    {
                        yield return new ValidationResult("Correct ZIP code is reqiered", new[] { "PostalCode" });
                    }

                    PostalCode = zipCode;
                }
            }

            Name = validate.DMCApitalize(Name);
            Address = validate.DMCApitalize(Address);
            Town = validate.DMCApitalize(Town);
            County = validate.DMCApitalize(County);

            if (!string.IsNullOrEmpty(HomePhone))
            {
                if (HomePhone.Count(c => Char.IsDigit(c)) != 10)
                    yield return new ValidationResult("Home phone must contain 10 digits", new[] { "HomePhone" });
                HomePhone = validate.DMCheckPhoneNumber(HomePhone);
            }
                
            if (!string.IsNullOrEmpty(CellPhone))
            {

                if (CellPhone.Count(c => Char.IsDigit(c)) != 10)
                    yield return new ValidationResult("Cell Phone must contain 10 digits", new[] { "CellPhone" });
                CellPhone = validate.DMCheckPhoneNumber(CellPhone);
            }

            yield return ValidationResult.Success;
        }

        public string TrimFunction(string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                return value.Trim();
            }
            else
            {
                return value;
            }
        }
    }

    public class FarmMetadata
    {
        public int FarmId { get; set; }
        [Display(Name = "Farm Name")]
        public string Name { get; set; }
        public string Address { get; set; }
        public string Town { get; set; }
        public string County { get; set; }
        [Remote("ValidateProvinceCode", "DMFarm")]
        public string ProvinceCode { get; set; }
        public string PostalCode { get; set; }
        public string HomePhone { get; set; }
        public string CellPhone { get; set; }
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        public string Directions { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        [DMDateNotInFuture]
        public DateTime? DateJoined { get; set; }
        [Display(Name = "Last Contact")]
        [DisplayFormat(DataFormatString = "{0:dd MMM yyyy}")]
        [DMDateNotInFuture]
        public DateTime? LastContactDate { get; set; }
        [Display(Name = "Province")]
        public Province ProvinceCodeNavigation { get; set; }
    }
}
