﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace a2OEC.Models
{
    public class OECContext_Singleton
    {
        private static OECContext _context;

        private static object syncLock = new object();

        public static OECContext Context()
        {
            if (_context == null)
            {
                lock (syncLock)
                {
                    if (_context == null)
                    {
                        var optionBuilder = new DbContextOptionsBuilder<OECContext>();
                        optionBuilder.UseSqlServer(@"Server=.\sqlexpress;Database=OEC;Trusted_Connection=True;");
                        _context = new OECContext(optionBuilder.Options);
                    }
                }
            }
            return _context;
        }

    }
}
