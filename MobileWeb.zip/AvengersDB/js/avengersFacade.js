/**
 * File Name: avengersFacade.js
 *
 * Revision History:
 *       Dmytro Maherya  : Created
 */

function showCalculatedAge() {
    var dob = $("#txtDOBAdd").val();
    $("#txtAge").val(getCurrentAge(dob));
}

function addFriendEnemy() {
    // 1. do validation
    if (doValidate_frmAddFriend()) {
        // 2. if succeeded then fetch info from form controls
        var name= $("#txtNameAdd").val();
        var fullName = $("#txtFullNameAdd").val();
        var dob = $("#txtDOBAdd").val();
        var isFriend = $("#radFriendAdd").prop("checked");

        console.info("Name: " + name +
        "Full Name: " + fullName +
        "Dob: " + dob+
        "Is Friend: " + isFriend);
        // 3. insert to the table (call insert function in DAL by supplying the info collected in step 2)

        var options = [name, fullName, dob, isFriend];
        function callBack(){
            console.info("Success: record inserted successfully");
        }
        Friend.insert(options, callBack );
    }
    else{
        console.error("Validation failed");
    }
}

function testValidation() {
    if (doValidate_frmExtra()) {
        console.info("Validation is successful");
    }
    else{
        console.error("Validation failed");
    }
}

function clearDatabase() {
    var result = confirm("Really want to clear database?");
    if (result) {
        try {
            DB.dropTables();
            alert("Database cleared");
        } catch (e) {
            alert(e);
        }


    }
}

function showAllFriendsEnemies() {
    var options = [];

    function callBack(tx, results) {

        var htmlcode = "";

        for (var i = 0; i < results.rows.length; i++) {
            var row = results.rows.item(i);
            console.info("Name: " + row['name'] +
            " Full Name: " + row['fullName'] +
            " DOB: " + row['dob'] +
                " Is Friend: " + row['isFriend']);


            htmlcode += "<li><a data-role='button' data-row-id=" + row['id'] + " href='#'>" +
                " <h1>Name: " + row['name'] + "</h1>" +
                " <h1>Full Name: " + row['fullName'] + "</h1>" +
                " <h1>DOB: " + row['dob'] + "</h1>" +
                " <h1>Is Friend: " + row['isFriend'] + "</h1>" +
                "</a></li>";
        }

        var lv = $("#lvAll");
        lv = lv.html(htmlcode);
        lv.listview("refresh"); //important

        //attach event handlers to each item

        $("#lvAll a").on("click", clickHandler);
        function clickHandler() {
            localStorage.setItem("id", $(this).attr("data-row-id"));

            //both will work
            $.mobile.changePage("#pageDetail", {transition: 'none'});
            // $(location).prop('href', "#pageDetail");

        }


    }
    Friend.selectAll(options, callBack);
}

function updateFriendEnemy() {
    // var id = $("#txtId").val();
    var id = localStorage.getItem("id");
    var name = $("#txtNameModify").val();
    var fullName = $("#txtFullNameModify").val();
    var dob = $("#txtDOBModify").val();
    var isFriend = $("#radFriendModify").prop("checked");

    //very important
    var options = [name, fullName, dob, isFriend, id];
    function callback() {
        console.info("Success: record updated successfully.");
    }

    Friend.update(options, callback);
}

function deleteFriendEnemy() {
    // var id = $("#txtId").val();
    var id = localStorage.getItem("id");
    var options = [id];
    function callback() {
        console.info("Success: Record deleted successfully");
        //navigate away to friends page
        $.mobile.changePage("#pageFriends", {transition: 'none'});
    }
    Friend.delete(options, callback);

}

function showOneFriend() {
    // var id = $("#txtId").val();
    var id = localStorage.getItem("id");

    var options = [id];
    function callback(tx, results) {
        var row = results.rows.item(0);
        console.info("Name: " + row['name'] +
            " Full Name: " + row['fullName'] +
            " DOB: " + row['dob'] +
            " Is Friend: " + row['isFriend']);

        $("#txtNameModify").val(row['name']);
        $("#txtFullNameModify").val(row['fullName']);
        $("#txtDOBModify").val(row['dob']);

        if (row['isFriend'] == 'true') {
            $("#radFriendModify").prop("checked", true);
        }
        else{
            //$("#radFriendModify").prop("checked", false); // will not work
            $("#radEnemyModify").prop("checked", true);
        }

        $("#frmModifyFriend :radio").checkboxradio("refresh");


    }
    Friend.select(options, callback);
}