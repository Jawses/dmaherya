
var db;

/**
 * General purpose error handler
 * @param tx The transaction object
 * @param error The error object
 */
function errorHandler(tx, error) {
    console.error("SQL error: " + tx + " (" + error.code + ") : " + error.message);
}

var DB = {
    createDatabase : function () {
        var shortName = "AvengersDB";
        var version = "1.0";
        var displayName = "DB for AvengersDB app";
        var dbSize = 2 * 1024 * 1024;

        function dbCreateSuccess() {
            console.info("Success: Database creation successful");
        }

        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);
    },
    createTables: function () {
        function txFunction(tx) {
            var sql = "CREATE TABLE IF NOT EXISTS friend( " +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                "name VARCHAR(20) NOT NULL, " +
                "fullName VARCHAR(20), " +
                "dob DATE, " +
                "isFriend VARCHAR(1));";

            var options = [];
            function successCreate() {
                console.info("Success: Tables created successfully");
            }

            tx.executeSql(sql, options, successCreate, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Create table transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction );

    },
    dropTables: function () {
        function txFunction(tx) {
            var sql = "DROP TABLE IF EXISTS friend;";
            var options = [];
            function successDrop() {
                console.info("Success: Tables dropped successfully");
            }
            tx.executeSql(sql, options, successDrop, errorHandler);
        }
        function successTransaction() {
            console.info("Success: Drop table transaction successful");
        }
        db.transaction(txFunction, errorHandler, successTransaction );
    }
};






























