/**
 * File Name: util.js
 *
 * Revision History:
 *       Sabbir Ahmed, 2018-02-20 : Created
 */


/**
 * calculates the age
 * @param dob the date of birth
 * @returns {number} the age
 */
function getCurrentAge(dob) {
    var year = Number(dob.substr(0, 4));
    var month = Number(dob.substr(5, 2)) - 1;
    var day = Number(dob.substr(8, 2));
    var today = new Date();
    var age = today.getFullYear() - year;
    if (today.getMonth() < month || (today.getMonth() == month && today.getDate() < day)) {
        age--;
    }
    return age;

}


function doValidate_frmAddFriend() {
    var form = $("#frmAddFriend");
    form.validate({
        rules: {
            txtNameAdd: {
                required: true,
                minlength: 2
            },
            txtFullNameAdd: {
                required: true,
                rangelength: [2, 20]
            },
            txtDOBAdd: {
                required: true,
                // min: "1990-01-01"
                agecheck: true
            }
        },
        messages: {
            txtNameAdd: {
                required: "You must enter name",
                minlength: "name must be at least 2 characters long"
            },
            txtFullNameAdd: {
                required: "You must enter Full name",
                rangelength: "Full name must be 2-20 characters long"
            },
            txtDOBAdd: {
                required: "You must enter DOB",
                // min: "Must be born after 1990-01-01"
                agecheck: "Age must be at least 2"
            }
        }
    });
    return form.valid();

}


jQuery.validator.addMethod("agecheck",
    function (value, element) {
        var age = getCurrentAge(value);
        if (age >= 2) {
            return true;
        }
        return false;
    },
    "Age Must be at least 2 ");


function doValidate_frmExtra() {
    var form = $("#frmExtra");
    form.validate({
        rules: {
            txtPassword: {
                required: true,
                passwordcheck: true,
                minlength: 8
            },
            txtVerifyPassword: {
                required: true,
                equalTo: "#txtPassword"
            },
            txtUrl: {
                required: true
            },
            txtEmail: {
                required: true,
                email: true,
                emailcheck: true
            }
        },
        messages: {
            txtPassword: {
                required: "Password is required",
                passwordcheck: "Password must contain at least 1 uppercase letter and 1 number",
                minlength: "Password must be at least 8 characters long"
            },
            txtVerifyPassword: {
                required: "Please re-enter password",
                equalTo: "Password is not same, re-enter"
            },
            txtUrl: {
                required: "You must enter a valid url"
            },
            txtEmail: {
                required: "you must enter email",
                email: "Enter a valid email",
                emailcheck: "Must be a conestoga email"
            }
        }
    });
    return form.valid();

}

jQuery.validator.addMethod("passwordcheck",
    function (value, element) {
        var regex = /([A-Za-z\d]*[A-Z]+[A-Za-z\d]*[\d]+[A-Za-z\d]*)|([A-Za-z\d]*[\d]+[A-Za-z\d]*[A-Z]+[A-Za-z\d]*)/;
        return this.optional(element) || regex.test(value);
    },
    "Our complicated password checker");

jQuery.validator.addMethod("emailcheck",
    function(value, element){
        var regex = /^.+@conestogac.on.ca$/;
        return this.optional(element) || regex.test(value);
    },
    "Valid conestoga email");