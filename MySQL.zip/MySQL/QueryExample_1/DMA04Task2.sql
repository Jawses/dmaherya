-- If MySQL is not started, run Services and run MySQL57 service

-- cd "C:\Program Files\MySQL\MySQL Server 5.7\bin"
-- mysql -u root -p < G:\mysql\swexpert\swexpert.sql
-- mysql -u root < G:\SQL\Asssignment4\DMA04Task2.sql > G:\SQL\Asssignment4\DMA04Task2.out 

SELECT '' AS 'Dima Maherya';
SELECT '' AS 'PROG2220: Section 1';
SELECT '' AS 'Assignment 4: Task 2';

SELECT SYSDATE() AS 'Current System Date';

USE swexpert;

SELECT '';
SELECT '' AS '*** Q1. SWE Exercise 1[2 points] ***';

SELECT ROUND(AVG(score), 1) AS 'Average Score'
FROM evaluation
WHERE (evaluatee_id = 105);

SELECT '';
SELECT '' AS '*** Q2. SWE Exercise 2[2 points] ***';

SELECT COUNT(c_id) AS 'Number of Certified'
FROM consultant_skill
WHERE skill_id = 1;

SELECT '';
SELECT '' AS '*** Q3. SWE Exercise 3[4 points] ***';

SELECT c_first, c_last
FROM consultant
WHERE c_id IN 
	(SELECT DISTINCT c_id FROM project_consultant WHERE p_id IN
		(SELECT p_id FROM project_consultant a JOIN consultant b USING(c_id) WHERE c_first = 'Mark' AND c_last = 'Myers'));

SELECT '';
SELECT '' AS '*** Q4. SWE Exercise 4[5 points] ***';

	SELECT p_id, project_name
	FROM project
	WHERE p_id IN (SELECT p_id FROM evaluation)
UNION 
	SELECT p_id, project_name
    FROM project
	WHERE mgr_id = (SELECT c_id FROM consultant WHERE LEFT(c_last, 1) = 'Z')
GROUP BY p_id;



