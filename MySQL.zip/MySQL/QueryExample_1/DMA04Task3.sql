-- If MySQL is not started, run Services and run MySQL57 service

-- cd "C:\Program Files\MySQL\MySQL Server 5.7\bin"
-- mysql -u root -p < G:\mysql\swexpert\swexpert.sql
-- mysql -u root --force< G:\SQL\Asssignment4\DMA04Task3.sql 1> G:\SQL\Asssignment4\DMA04Task3.out 2>G:\SQL\Asssignment4\DMA04Task3.err

SELECT '' AS 'Dima Maherya';
SELECT '' AS 'PROG2220: Section 1';
SELECT '' AS 'Assignment 4: Task 3';

SELECT SYSDATE() AS 'Current System Date';

USE swexpert;

SELECT '';
SELECT '' AS '*** Q1. SWE Exercise 1[4 points] ***';

ALTER TABLE project_consultant
ADD total_days VARCHAR(20) NOT NULL default 0;

UPDATE project_consultant
SET total_days = DATEDIFF(roll_off_date, roll_on_date);

SELECT * FROM project_consultant;

ALTER TABLE project_consultant
DROP total_days;

SELECT '';
SELECT '' AS '*** Q2. SWE Exercise 2[4 points] ***';

DROP TABLE evaluation_audit;

CREATE TABLE evaluation_audit (
	audit_id int AUTO_INCREMENT,
    audit_e_id int NOT NULL,
    audit_score int,
    audit_user varchar(20),
    PRIMARY KEY (audit_id)
);

INSERT INTO evaluation_audit
SET audit_e_id = 100, audit_score = 90;


SELECT ROW_COUNT() AS "INSERT: rows affected  ";

SELECT * FROM evaluation_audit;


SELECT '';
SELECT '' AS '*** Q3. SWE Exercise 3[5 points] ***';

ALTER TABLE evaluation_audit
  MODIFY audit_user VARCHAR(100) NOT NULL DEFAULT '';
  
ALTER TABLE evaluation_audit
ADD audit_date date NOT NULL default 0;

INSERT INTO evaluation_audit
SET audit_e_id = 100, audit_score = 95, audit_user = USER(), audit_date = SYSDATE();


SELECT ROW_COUNT() AS "INSERT: rows affected  ";

SELECT * FROM evaluation_audit;

INSERT INTO evaluation_audit
SET audit_e_id = 100, audit_score = 99, audit_user = NULL, audit_date = NULL;


SELECT ROW_COUNT() AS "INSERT: rows affected (negative test: check err file) ";

SELECT '';
SELECT '' AS '*** Q4. SWE Exercise 4[1 points] ***';

INSERT INTO project_skill
SET skill_id = NULL;

SELECT ROW_COUNT() AS "INSERT: rows affected (negative test: check err file) ";

SELECT '';
SELECT '' AS '*** Q5. SWE Exercise 5[2 points] ***';

DELETE FROM consultant
WHERE c_id = 100;

SELECT ROW_COUNT() AS "DELETE: rows affected (negative test: check err file) ";

