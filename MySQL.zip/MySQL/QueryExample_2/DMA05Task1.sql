-- If MySQL is not started, run Services and run MySQL57 service

-- cd "C:\Program Files\MySQL\MySQL Server 5.7\bin"
-- mysql -u root -p < G:\mysql\mgs_ex_starts\create_my_guitar_shop.sql
-- mysql -u root < G:\SQL\Assignment5\DMA05Task1.sql > G:\SQL\Assignment5\DMA05Task1.out 

SELECT '' AS 'Dima Maherya';
SELECT '' AS 'PROG2220: Section 1';
SELECT '' AS 'Assignment 5: Task 1';

SELECT SYSDATE() AS 'Current System Date';

USE my_guitar_shop;

SELECT '';
SELECT '' AS '*** Task 1, Q1.  MGS Exercise 8-1[5 points] ***';

SELECT FORMAT(list_price, 2) AS list_price,
	CAST(discount_percent as SIGNED) AS discount_percent,
    ROUND((list_price * 0.01*discount_percent), 2) AS discount_amount,
    DATE_FORMAT(date_added, "%m-%d") AS month_day_added
FROM products;

SELECT '';
SELECT '' AS '*** Task 1, Q2.  MGS Exercise 9-2[5 points] ***';

SELECT order_date, 
	DATE_FORMAT(order_date, "%Y"), 
    DATE_FORMAT(order_date, "%b-%d-%Y"), 
    DATE_FORMAT(order_date, "%r"), 
    DATE_FORMAT(order_date, "%m-%d-%y %I:%i")
FROM orders;

SELECT '';
SELECT '' AS '*** Task 1, Q3.  MGS Exercise 9-3[5 points] ***';

SELECT card_number,
	LENGTH(card_number) AS card_number_length,
	RIGHT(card_number, 4) AS last_four_digits,
    CONCAT("XXXX-XXXX-XXXX-", RIGHT(card_number, 4)) AS formatted_number
FROM orders;

SELECT '';
SELECT '' AS '*** Task 1, Q4.  MGS Exercise 9-4[5 points] ***';

SELECT order_id, order_date, 
	DATE_ADD(order_date, INTERVAL 2 DAY) AS est_ship_date, 
    IFNULL(ship_date,"Not Shipped") AS ship_date,
    DATEDIFF(ship_date, order_date) AS days_to_ship
FROM orders
WHERE order_date >=  '2015-04-01' AND order_date <=  '2015-04-30';



