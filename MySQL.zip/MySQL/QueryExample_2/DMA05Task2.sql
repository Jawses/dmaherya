-- If MySQL is not started, run Services and run MySQL57 service

-- cd "C:\Program Files\MySQL\MySQL Server 5.7\bin"
-- mysql -u root -p < G:\mysql\swexpert\swexpert.sql
-- mysql -u root < G:\SQL\Assignment5\DMA05Task2.sql > G:\SQL\Assignment5\DMA05Task2.out 

SELECT '' AS 'Dima Maherya';
SELECT '' AS 'PROG2220: Section 1';
SELECT '' AS 'Assignment 5: Task 2';

SELECT SYSDATE() AS 'Current System Date';

USE swexpert;

SELECT '';
SELECT '' AS '*** Q1. SWE Exercise 1[5 points] ***';

SELECT CONCAT_WS(" ",ROUND(AVG(score), 2), c.c_first, c.c_last) AS average
FROM evaluation e
	JOIN consultant c ON e.evaluatee_id = c.c_id
WHERE c.c_first = 'Janet' AND c.c_last = 'Park';

SELECT '';
SELECT '' AS '*** Q2. SWE Exercise 2[5 points] ***';

SELECT RPAD(p_id, 5, " ") AS p_id,
	RPAD(c_id, 5, " ") AS c_id,
    CASE WHEN (LENGTH((FLOOR((DATEDIFF(roll_off_date, roll_on_date)/30.4)))) = 2) THEN LPAD(FLOOR((DATEDIFF(roll_off_date, roll_on_date)/30.4)), 6 , " ") ELSE LPAD(FLOOR((DATEDIFF(roll_off_date, roll_on_date)/30.4)), 6, " ") END AS months
FROM project_consultant; 

SELECT '';
SELECT '' AS '*** Q3. SWE Exercise 3[5 points] ***';

SELECT 
	LPAD(s.c_id, 4, " ") as c_id, 
	RPAD(CONCAT_WS(", ", c.c_last, c.c_first), 20, " ") AS consultant_full_name,
    LPAD(s.skill_id, 8, " ") as skill_id,
	
--    RPAD(CASE WHEN (s.certification = 'Y') THEN 'Certified' WHEN (s.certification = 'N') THEN 'NOT Certified' ELSE 'Unknown' END , 15, " ")AS certification
	CASE WHEN (s.certification = 'Y') THEN 'Certified' WHEN (s.certification = 'N') THEN 'NOT Certified' ELSE 'Unknown' END AS certification
FROM consultant_skill s 
	JOIN consultant c USING(c_id);

